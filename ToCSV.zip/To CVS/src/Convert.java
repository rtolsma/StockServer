import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Convert {

	public static void main(String[] args) throws FileNotFoundException {
		ArrayList<String[]> MyArrayList = new ArrayList<String[]>();//set up array list
		Scanner input = new Scanner(new File("AAPL_5min.txt"));//takes file input
		PrintStream output = new PrintStream(new File("Output.txt"));//sets up export file
		Scanner Scan =new Scanner(System.in);
		System.out.println("how many rows are there total");
		int rows=Scan.nextInt()-1;
		String[][] column=new String[rows][6];
		for(int i=0;i<rows;i++){
			for(int j=0;j<6;j++){
				column[i][j]=input.next();
				
			}
			
		}
		for (int i = 0; i < rows; i++) {//for loop that runs until arraylist is sone
			output.println(column[i][0]+","+column[i][1]+","+column[i][2]+","+column[i][3]+","+column[i][4]+","+column[i][5]);//prints it to a file
		}
		/*String[] column=new String[6];
		while (input.hasNext()) {//populates the array list
			for(int i=0; i<=5;i++){
					column[i]=input.next();
			}
			MyArrayList.add(column);
		} 
		
		for (int i = 0; i < a; i++) {//for loop that runs until arraylist is sone
			column = MyArrayList.get(i);
			output.println(column[0]+","+column[1]+","+column[2]+","+column[3]+","+column[4]);//prints it to a file
		}
	}
*/
}
}
